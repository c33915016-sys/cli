export interface OtpItem {
  id: number;
  ts: number;
  service: string;
  number: string;
  range: string;
  country: string;
  flag: string;
  code: string;
  message: string;
  source: 'stexsms_api' | 'console' | 'bot';
  packetId?: string;
}

export interface RentedNumber {
  id: string;
  number: string;
  service: string;
  country: string;
  flag: string;
  rentedAt: number;
  expiresAt: number;
  status: 'waiting' | 'received' | 'expired' | 'cancelled';
  receivedCode?: string;
  receivedMessage?: string;
  userId?: string;
}

export interface CountryInfo {
  name: string;
  code: string;
  flag: string;
  prefix: string;
}

export interface ServiceInfo {
  name: string;
  letter: string;
  color: string;
  defaultMsg: string;
}

export interface ApiConfig {
  ok: boolean;
  brand: string;
  apiKey: string;
  apiKeyMasked: string;
  botLink: string;
  status: string;
  countries: CountryInfo[];
  services: ServiceInfo[];
  totalToday: number;
  pollMs: number;
}
