import React, { useState, useEffect, useRef } from 'react';
import { Navbar } from './components/Navbar';
import { LiveFeed } from './components/LiveFeed';
import { OtpItem, ServiceInfo } from './types';
import { playOtpChime, triggerHaptic } from './utils/audio';
import { Send, ExternalLink } from 'lucide-react';

export default function App() {
  const [items, setItems] = useState<OtpItem[]>([]);
  const [todayCount, setTodayCount] = useState<number>(384);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isSearching, setIsSearching] = useState<boolean>(false);
  const [freshIds, setFreshIds] = useState<Set<number>>(new Set());
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [botLink] = useState<string>('https://t.me/EX_NUMBER_0BOT');

  const [services, setServices] = useState<ServiceInfo[]>([
    { name: 'Facebook', letter: 'f', color: '#1877f2', defaultMsg: 'is your Facebook code.' },
    { name: 'WhatsApp', letter: 'W', color: '#25d366', defaultMsg: 'is your WhatsApp code.' },
    { name: 'Telegram', letter: 'T', color: '#2aabee', defaultMsg: 'is your Telegram code.' },
    { name: 'Instagram', letter: 'I', color: '#e1306c', defaultMsg: 'is your Instagram code.' },
    { name: 'Google', letter: 'G', color: '#ea4335', defaultMsg: 'is your Google code.' },
    { name: 'TikTok', letter: 'T', color: '#fe2c55', defaultMsg: 'is your TikTok code.' },
    { name: 'bKash', letter: 'b', color: '#e2136e', defaultMsg: 'is your bKash OTP.' },
    { name: 'Binance', letter: 'B', color: '#f0b90b', defaultMsg: 'is your Binance code.' },
    { name: 'Discord', letter: 'D', color: '#5865f2', defaultMsg: 'is your Discord code.' },
    { name: 'Microsoft', letter: 'M', color: '#00a4ef', defaultMsg: 'is your Microsoft code.' },
    { name: 'IMO', letter: 'i', color: '#0aa0ff', defaultMsg: 'is your IMO code.' },
    { name: 'Snapchat', letter: 'S', color: '#fffc00', defaultMsg: 'is your Snapchat code.' },
  ]);

  const lastIdRef = useRef<number>(0);
  const knownIdsRef = useRef<Set<number>>(new Set());

  // Show bottom toast notification
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2800);
  };

  // Initial load config
  useEffect(() => {
    fetch('/api/config')
      .then(res => res.json())
      .then(data => {
        if (data.ok) {
          if (data.services) setServices(data.services);
          if (data.totalToday) setTodayCount(data.totalToday);
        }
      })
      .catch(() => {});
  }, []);

  // Main polling engine
  useEffect(() => {
    let isMounted = true;

    const poll = async () => {
      if (document.hidden) return;

      // If active search
      if (searchQuery.trim().length >= 4) {
        setIsSearching(true);
        try {
          const res = await fetch(`/api/search?number=${encodeURIComponent(searchQuery.trim())}`);
          const data = await res.json();
          if (isMounted && data.ok) {
            const searchSeen = new Set<number>();
            const dedupedSearch: OtpItem[] = [];
            (data.items || []).forEach((it: OtpItem) => {
              if (!searchSeen.has(it.id)) {
                searchSeen.add(it.id);
                dedupedSearch.push(it);
              }
            });
            setItems(dedupedSearch);
          }
        } catch {}
        return;
      }

      setIsSearching(false);

      // Normal console feed poll
      try {
        const res = await fetch(`/api/console?after=${lastIdRef.current}`);
        const data = await res.json();

        if (isMounted && data.ok) {
          if (data.today) setTodayCount(data.today);

          const newItems: OtpItem[] = data.items || [];
          if (newItems.length > 0) {
            const incomingFresh: number[] = [];
            newItems.forEach(it => {
              if (!knownIdsRef.current.has(it.id)) {
                knownIdsRef.current.add(it.id);
                incomingFresh.push(it.id);
              }
              if (it.id > lastIdRef.current) {
                lastIdRef.current = it.id;
              }
            });

            if (incomingFresh.length > 0) {
              setFreshIds(new Set(incomingFresh));

              if (knownIdsRef.current.size > newItems.length) {
                if (soundEnabled) {
                  playOtpChime();
                }
                triggerHaptic('ok');
                const latest = newItems[0];
                showToast(`New ${latest.service} OTP: ${latest.code}`);
              }
            }

            // Strictly deduplicate by item ID
            setItems(prev => {
              const itemMap = new Map<number, OtpItem>();
              newItems.forEach(it => itemMap.set(it.id, it));
              prev.forEach(it => {
                if (!itemMap.has(it.id)) {
                  itemMap.set(it.id, it);
                }
              });
              return Array.from(itemMap.values())
                .sort((a, b) => b.id - a.id)
                .slice(0, 100);
            });
          }
        }
      } catch {}
    };

    poll();
    const interval = setInterval(poll, 3000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [searchQuery, soundEnabled]);

  const handleOpenBot = () => {
    triggerHaptic('light');
    try {
      const tg = (window as unknown as { Telegram?: { WebApp?: { openTelegramLink?: (url: string) => void } } }).Telegram?.WebApp;
      if (tg?.openTelegramLink) {
        tg.openTelegramLink(botLink);
        return;
      }
    } catch {}
    window.open(botLink, '_blank');
  };

  return (
    <div className="min-h-screen bg-[#07090a] text-[#f2f5f3] flex flex-col selection:bg-emerald-500/30 selection:text-white pb-20 sm:pb-12">
      {/* Navbar with brand and Bot button */}
      <Navbar
        todayCount={todayCount}
        soundEnabled={soundEnabled}
        setSoundEnabled={setSoundEnabled}
        botLink={botLink}
      />

      {/* Main Content: Pure Live Console Feed */}
      <main className="flex-1 max-w-3xl w-full mx-auto px-4 py-5 sm:py-6">
        <LiveFeed
          items={items}
          services={services}
          todayCount={todayCount}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          onClearSearch={() => setSearchQuery('')}
          isSearching={isSearching}
          freshIds={freshIds}
        />
      </main>

      {/* Floating Action Button (FAB) for Telegram Bot */}
      <button
        onClick={handleOpenBot}
        aria-label="Open Telegram Bot"
        title="Open Telegram Bot"
        className="fixed right-5 bottom-6 z-40 w-13 h-13 rounded-full bg-gradient-to-tr from-[#1b8fd0] to-[#38b6f2] shadow-[0_10px_30px_rgba(42,171,238,0.5)] flex items-center justify-center text-white active:scale-90 hover:scale-105 transition-all hover:shadow-[0_12px_35px_rgba(42,171,238,0.65)]"
      >
        <Send className="w-5 h-5 mr-0.5 -rotate-12" />
      </button>

      {/* Floating Toast Notification (Positioned at Top to never overlap cards or FAB) */}
      {toastMessage && (
        <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-full bg-emerald-400 text-black font-black text-xs tracking-wider shadow-[0_12px_36px_rgba(18,184,104,0.65)] flex items-center gap-2 border border-emerald-300 animate-in fade-in slide-in-from-top-4 duration-300">
          <span className="w-2 h-2 rounded-full bg-black animate-ping"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Footer */}
      <footer className="border-t border-white/[0.08] bg-[#07090a] py-6 px-4 mt-auto text-center text-xs text-neutral-500">
        <div className="max-w-3xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="text-neutral-400 font-medium">
            Powered by <strong className="text-white">EX LIVE OTP</strong> &bull; Always Connected
          </div>

          <button
            onClick={handleOpenBot}
            className="text-[#2aabee] hover:text-[#50c2ff] transition-colors flex items-center gap-1.5 font-bold"
          >
            <span>@EX_NUMBER_0BOT</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </button>
        </div>
      </footer>
    </div>
  );
}
