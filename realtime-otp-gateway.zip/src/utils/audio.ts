let audioCtx: AudioContext | null = null;

export function playOtpChime() {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!audioCtx) {
      audioCtx = new AudioContextClass();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    const now = audioCtx.currentTime;
    
    // Clean high modern ping (two-tone chime: 880Hz then 1320Hz)
    const osc1 = audioCtx.createOscillator();
    const gain1 = audioCtx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(784, now); // G5
    osc1.frequency.exponentialRampToValueAtTime(1046.5, now + 0.12); // C6

    gain1.gain.setValueAtTime(0.15, now);
    gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    osc1.connect(gain1);
    gain1.connect(audioCtx.destination);

    osc1.start(now);
    osc1.stop(now + 0.36);
  } catch {
    // Audio may be blocked by browser policy until user interacts
  }
}

export function triggerHaptic(type: 'light' | 'medium' | 'heavy' | 'ok' | 'err' = 'light') {
  try {
    const tg = (window as unknown as { Telegram?: { WebApp?: { HapticFeedback?: { notificationOccurred: (s: string) => void; impactOccurred: (s: string) => void } } } }).Telegram?.WebApp;
    if (tg?.HapticFeedback) {
      if (type === 'ok') tg.HapticFeedback.notificationOccurred('success');
      else if (type === 'err') tg.HapticFeedback.notificationOccurred('error');
      else tg.HapticFeedback.impactOccurred(type);
      return;
    }

    if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
      if (type === 'ok') navigator.vibrate([40, 60, 40]);
      else if (type === 'err') navigator.vibrate([80, 50, 80]);
      else navigator.vibrate(30);
    }
  } catch {
    // Vibration not supported
  }
}
