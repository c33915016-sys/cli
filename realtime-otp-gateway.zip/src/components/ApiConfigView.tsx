import React, { useState } from 'react';
import { 
  Key, 
  Check, 
  Copy, 
  Terminal, 
  Code2, 
  Send, 
  ShieldCheck, 
  Globe, 
  ExternalLink,
  Layers
} from 'lucide-react';
import { triggerHaptic } from '../utils/audio';

interface ApiConfigViewProps {
  apiKey: string;
  botLink: string;
  onSendTestOtp: (payload: { number: string; service: string; code: string; message: string }) => void;
}

export const ApiConfigView: React.FC<ApiConfigViewProps> = ({
  apiKey,
  botLink,
  onSendTestOtp,
}) => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [testNumber, setTestNumber] = useState('+33756981245');
  const [testService, setTestService] = useState('WhatsApp');
  const [testCode, setTestCode] = useState('583921');
  const [testMessage, setTestMessage] = useState('583921 is your WhatsApp verification code.');

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    triggerHaptic('ok');
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleTriggerTest = (e: React.FormEvent) => {
    e.preventDefault();
    onSendTestOtp({
      number: testNumber,
      service: testService,
      code: testCode,
      message: testMessage,
    });
    triggerHaptic('ok');
  };

  const curlExample = `curl -X POST "${window.location.origin}/api/webhook/sms" \\
  -H "Content-Type: application/json" \\
  -H "x-api-key: ${apiKey}" \\
  -d '{
    "number": "+33756981245",
    "service": "WhatsApp",
    "code": "849201",
    "country": "France",
    "message": "849201 is your verification code."
  }'`;

  const nodeExample = `// Node.js / Telegram Bot forwarder
const fetch = require('node-fetch');

async function sendOtpToConsole(otpData) {
  const res = await fetch('${window.location.origin}/api/webhook/sms', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': '${apiKey}'
    },
    body: JSON.stringify(otpData)
  });
  return await res.json();
}`;

  return (
    <div className="space-y-6">
      {/* API Key Status Hero */}
      <div className="p-6 rounded-2xl bg-[#0e1512] border border-emerald-500/30 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold uppercase tracking-wider text-white flex items-center gap-2">
                <span>StexSMS API Integration</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase bg-emerald-500 text-black">
                  CONNECTED
                </span>
              </h2>
              <p className="text-xs text-neutral-400">
                Authenticated with user key &bull; Real-time OTP ingestion active
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={botLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#2aabee]/15 border border-[#2aabee]/40 text-[#2aabee] hover:bg-[#2aabee]/25 text-xs font-bold transition-colors"
            >
              <span>Telegram Bot</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* API Key box */}
        <div className="p-4 rounded-xl bg-black/60 border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">
              StexSMS Secret API Key
            </span>
            <div className="font-mono text-xl sm:text-2xl font-black text-emerald-400 selection:bg-emerald-500/30">
              {apiKey}
            </div>
          </div>

          <button
            onClick={() => handleCopy(apiKey, 'main_key')}
            className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-bold text-white transition-colors self-start sm:self-auto"
          >
            {copiedKey === 'main_key' ? (
              <>
                <Check className="w-4 h-4 text-emerald-400" />
                <span>Copied</span>
              </>
            ) : (
              <>
                <Copy className="w-4 h-4 text-neutral-400" />
                <span>Copy API Key</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Manual Webhook / Bot Simulation Form */}
      <div className="p-6 rounded-2xl bg-[#0e1512] border border-white/10 space-y-4">
        <div>
          <h3 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Send className="w-4 h-4 text-emerald-400" />
            <span>Test Webhook / Forwarder Ingest</span>
          </h3>
          <p className="text-xs text-neutral-400">
            Inject a custom SMS message or OTP directly to test real-time delivery to the live feed and console.
          </p>
        </div>

        <form onSubmit={handleTriggerTest} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1">
              Phone Number
            </label>
            <input
              type="text"
              value={testNumber}
              onChange={(e) => setTestNumber(e.target.value)}
              className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-xs font-mono text-white outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1">
              Service
            </label>
            <input
              type="text"
              value={testService}
              onChange={(e) => setTestService(e.target.value)}
              className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-xs text-white outline-none focus:border-emerald-500"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1">
              OTP Code
            </label>
            <input
              type="text"
              value={testCode}
              onChange={(e) => setTestCode(e.target.value)}
              className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-xs font-mono font-bold text-emerald-400 outline-none focus:border-emerald-500"
            />
          </div>

          <div className="sm:col-span-3">
            <label className="block text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-1">
              SMS Message Payload
            </label>
            <input
              type="text"
              value={testMessage}
              onChange={(e) => setTestMessage(e.target.value)}
              className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-xs font-mono text-white outline-none focus:border-emerald-500"
            />
          </div>

          <div className="sm:col-span-3 pt-2">
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider flex items-center gap-2 transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Send OTP to Console</span>
            </button>
          </div>
        </form>
      </div>

      {/* Code Snippets for Developers & Bot Admins */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* cURL Snippet */}
        <div className="p-5 rounded-2xl bg-[#0e1512] border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span>cURL Webhook Push</span>
            </h4>
            <button
              onClick={() => handleCopy(curlExample, 'curl')}
              className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white"
              title="Copy cURL"
            >
              {copiedKey === 'curl' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
          <pre className="p-3.5 rounded-xl bg-black/70 border border-white/5 text-[11px] font-mono text-neutral-300 overflow-x-auto leading-relaxed">
            {curlExample}
          </pre>
        </div>

        {/* Node.js Snippet */}
        <div className="p-5 rounded-2xl bg-[#0e1512] border border-white/10 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white flex items-center gap-2">
              <Code2 className="w-4 h-4 text-emerald-400" />
              <span>Telegram Bot / Node Forwarder</span>
            </h4>
            <button
              onClick={() => handleCopy(nodeExample, 'node')}
              className="p-1.5 rounded hover:bg-neutral-800 text-neutral-400 hover:text-white"
              title="Copy Node.js code"
            >
              {copiedKey === 'node' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>
          <pre className="p-3.5 rounded-xl bg-black/70 border border-white/5 text-[11px] font-mono text-neutral-300 overflow-x-auto leading-relaxed">
            {nodeExample}
          </pre>
        </div>
      </div>
    </div>
  );
};
