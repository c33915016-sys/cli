import React, { useState } from 'react';
import { 
  Terminal as TerminalIcon, 
  Play, 
  Pause, 
  Trash2, 
  Check, 
  Copy, 
  ArrowDownRight, 
  Layers, 
  Activity, 
  ShieldCheck, 
  Filter
} from 'lucide-react';
import { OtpItem } from '../types';
import { triggerHaptic } from '../utils/audio';

interface ConsoleStreamProps {
  items: OtpItem[];
  apiKey: string;
}

export const ConsoleStream: React.FC<ConsoleStreamProps> = ({ items, apiKey }) => {
  const [isPaused, setIsPaused] = useState(false);
  const [selectedItem, setSelectedItem] = useState<OtpItem | null>(null);
  const [copied, setCopied] = useState(false);
  const [filterType, setFilterType] = useState<string>('all');

  const streamItems = isPaused ? items.slice(0, 30) : items;

  const filteredItems = streamItems.filter(it => {
    if (filterType === 'all') return true;
    if (filterType === 'stexsms' && it.source === 'stexsms_api') return true;
    if (filterType === 'console' && it.source === 'console') return true;
    if (filterType === 'bot' && it.source === 'bot') return true;
    return true;
  });

  const handleCopyRaw = (text: string) => {
    navigator.clipboard.writeText(text);
    triggerHaptic('ok');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-4">
      {/* Console Top Toolbar */}
      <div className="p-4 rounded-2xl bg-[#0b100e] border border-white/10 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <TerminalIcon className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
              <span>StexSMS Realtime Console</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            </h2>
            <p className="text-xs text-neutral-400 font-mono">
              API KEY: <strong className="text-emerald-300">{apiKey}</strong> &bull; Protocol: HTTPS Stream Polling
            </p>
          </div>
        </div>

        {/* Console Controls */}
        <div className="flex items-center gap-2">
          {/* Filter */}
          <div className="flex items-center gap-1 bg-black/40 p-1 rounded-lg border border-white/10 text-xs">
            <Filter className="w-3.5 h-3.5 text-neutral-400 ml-1.5" />
            <select
              value={filterType}
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-transparent text-neutral-300 font-mono text-xs pr-2 outline-none"
            >
              <option value="all" className="bg-neutral-900">All Packets</option>
              <option value="stexsms" className="bg-neutral-900">StexSMS API</option>
              <option value="console" className="bg-neutral-900">Console Stream</option>
              <option value="bot" className="bg-neutral-900">Bot Ingest</option>
            </select>
          </div>

          {/* Pause / Resume */}
          <button
            onClick={() => {
              setIsPaused(!isPaused);
              triggerHaptic('light');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold font-mono flex items-center gap-1.5 border transition-all ${
              isPaused
                ? 'bg-amber-500/10 border-amber-500/30 text-amber-400 hover:bg-amber-500/20'
                : 'bg-neutral-900 border-white/10 text-neutral-300 hover:text-white'
            }`}
          >
            {isPaused ? <Play className="w-3.5 h-3.5 text-amber-400" /> : <Pause className="w-3.5 h-3.5" />}
            <span>{isPaused ? 'RESUME' : 'PAUSE'}</span>
          </button>
        </div>
      </div>

      {/* Terminal View */}
      <div className="rounded-2xl bg-[#040605] border border-emerald-500/20 shadow-2xl overflow-hidden font-mono text-xs">
        {/* Terminal Header Bar */}
        <div className="px-4 py-2.5 bg-neutral-950 border-b border-white/[0.08] flex items-center justify-between text-neutral-400">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500/80 inline-block"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80 inline-block"></span>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80 inline-block"></span>
            </div>
            <span className="ml-2 font-bold text-neutral-300 text-[11px]">stexsms-console@runtime:~#</span>
          </div>

          <div className="flex items-center gap-3 text-[11px]">
            <span className="text-emerald-400 font-bold flex items-center gap-1">
              <Activity className="w-3.5 h-3.5" />
              LIVE 3000ms
            </span>
            <span className="text-neutral-500 hidden sm:inline">200 OK</span>
          </div>
        </div>

        {/* Stream Entries */}
        <div className="p-3 max-h-[540px] overflow-y-auto space-y-2 divide-y divide-white/[0.04]">
          {filteredItems.map((item, index) => {
            const timeStr = new Date(item.ts * 1000).toISOString().split('T')[1].replace('Z', '');
            return (
              <div
                key={`cs_${item.id}_${index}`}
                onClick={() => setSelectedItem(item)}
                className="pt-2 hover:bg-emerald-500/[0.03] p-2 rounded-lg cursor-pointer transition-colors group"
              >
                <div className="flex flex-wrap items-center gap-2 text-neutral-400 text-[11px] leading-relaxed">
                  <span className="text-neutral-600">[{timeStr}]</span>
                  <span className="px-1.5 py-0.2 rounded bg-neutral-900 border border-white/10 text-neutral-300 font-bold">
                    {item.packetId || `STX-${item.id}`}
                  </span>
                  <span className="px-1.5 py-0.2 rounded bg-emerald-500/10 text-emerald-400 font-bold uppercase">
                    INCOMING_OTP
                  </span>
                  <span className="text-white font-bold">{item.service}</span>
                  <span className="text-neutral-500">&rarr;</span>
                  <span className="text-emerald-300 font-bold">{item.number}</span>
                  <span className="text-neutral-500">|</span>
                  <span className="text-neutral-300">{item.country}</span>
                  <span className="ml-auto flex items-center gap-2">
                    <span className="font-bold text-white bg-black/60 px-2 py-0.5 rounded border border-emerald-500/30 text-emerald-400">
                      CODE: {item.code}
                    </span>
                    <ArrowDownRight className="w-3.5 h-3.5 text-neutral-600 group-hover:text-emerald-400 transition-colors" />
                  </span>
                </div>
                <div className="text-[11px] text-neutral-500 mt-1 pl-2 border-l border-emerald-500/20 truncate">
                  payload: &quot;{item.message}&quot;
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Packet Inspector Drawer / Modal */}
      {selectedItem && (
        <div className="p-4 sm:p-5 rounded-2xl bg-neutral-950 border border-emerald-500/30 shadow-2xl space-y-3">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-400" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Packet Inspector: {selectedItem.packetId || `STX-${selectedItem.id}`}
              </h3>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleCopyRaw(JSON.stringify(selectedItem, null, 2))}
                className="flex items-center gap-1 px-2.5 py-1 rounded bg-neutral-900 border border-white/10 hover:border-emerald-500 text-neutral-300 text-xs font-mono"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy JSON'}</span>
              </button>
              <button
                onClick={() => setSelectedItem(null)}
                className="text-neutral-500 hover:text-white text-xs px-2 py-1 font-mono"
              >
                Close
              </button>
            </div>
          </div>

          <pre className="p-3 rounded-xl bg-black/80 border border-white/10 font-mono text-[11px] text-emerald-400 overflow-x-auto leading-relaxed">
            {JSON.stringify(selectedItem, null, 2)}
          </pre>
        </div>
      )}
    </div>
  );
};
