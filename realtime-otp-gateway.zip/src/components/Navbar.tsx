import React from 'react';
import { 
  Volume2, 
  VolumeX, 
  ExternalLink, 
  Send
} from 'lucide-react';
import { triggerHaptic } from '../utils/audio';

interface NavbarProps {
  todayCount: number;
  soundEnabled: boolean;
  setSoundEnabled: (enabled: boolean | ((prev: boolean) => boolean)) => void;
  botLink: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  todayCount,
  soundEnabled,
  setSoundEnabled,
  botLink,
}) => {
  return (
    <header className="border-b border-white/[0.08] bg-[#07090a]/95 backdrop-blur-xl sticky top-0 z-40 transition-all">
      {/* Top subtle emerald laser line */}
      <div className="h-[2px] w-full bg-gradient-to-r from-emerald-500 via-teal-300 to-emerald-600 opacity-90" />

      <div className="max-w-3xl mx-auto px-4 py-3 sm:py-3.5">
        <div className="flex items-center justify-between gap-3">
          {/* Brand: EX LIVE OTP */}
          <div className="flex items-center gap-3">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 via-emerald-600/10 to-transparent border border-emerald-500/30 shadow-[0_0_24px_rgba(18,184,104,0.3)] flex-none">
              <span className="font-mono font-black text-sm tracking-tighter text-emerald-400">
                EX
              </span>
              <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base sm:text-lg font-black tracking-wider uppercase text-white font-sans">
                  <span className="text-emerald-400 drop-shadow-[0_0_12px_rgba(18,184,104,0.5)]">EX</span> LIVE OTP
                </h1>
                <span className="text-[10px] font-mono font-bold tracking-widest px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/25 text-emerald-400">
                  REALTIME
                </span>
              </div>
              <p className="text-[11px] text-neutral-400 tracking-wide">
                Real-time codes &bull; Always connected
              </p>
            </div>
          </div>

          {/* Right actions: Audio toggle + Bot button */}
          <div className="flex items-center gap-2">
            {/* Audio Toggle */}
            <button
              onClick={() => {
                setSoundEnabled(prev => !prev);
                triggerHaptic('light');
              }}
              aria-label={soundEnabled ? 'Mute sound' : 'Enable sound'}
              title={soundEnabled ? 'Mute OTP alert sound' : 'Enable OTP alert sound'}
              className={`p-2.5 rounded-xl border transition-all ${
                soundEnabled 
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20 shadow-[0_0_15px_rgba(18,184,104,0.15)]' 
                  : 'bg-neutral-900/80 border-white/10 text-neutral-500 hover:text-neutral-300'
              }`}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </button>

            {/* Telegram Bot Link */}
            <a
              href={botLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#2aabee] to-[#1c92d2] hover:from-[#35b5f8] hover:to-[#229bdc] text-white text-xs font-black uppercase tracking-wider transition-all shadow-[0_4px_16px_rgba(42,171,238,0.35)] active:scale-95 hover:shadow-[0_6px_20px_rgba(42,171,238,0.5)]"
            >
              <Send className="w-3.5 h-3.5 -rotate-12" />
              <span>Bot</span>
              <ExternalLink className="w-3 h-3 opacity-80" />
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};
