import React, { useState } from 'react';
import { 
  Search, 
  X, 
  Copy, 
  Check, 
  Globe, 
  Radio, 
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { OtpItem, ServiceInfo } from '../types';
import { triggerHaptic } from '../utils/audio';

interface LiveFeedProps {
  items: OtpItem[];
  services: ServiceInfo[];
  todayCount: number;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onClearSearch: () => void;
  isSearching: boolean;
  freshIds: Set<number>;
}

export const LiveFeed: React.FC<LiveFeedProps> = ({
  items,
  services,
  todayCount,
  searchQuery,
  setSearchQuery,
  onClearSearch,
  isSearching,
  freshIds,
}) => {
  const [selectedService, setSelectedService] = useState<string>('all');
  const [selectedCountry, setSelectedCountry] = useState<string>('all');
  const [copiedMap, setCopiedMap] = useState<Record<string, boolean>>({});

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    triggerHaptic('ok');
    setCopiedMap(prev => ({ ...prev, [key]: true }));
    setTimeout(() => {
      setCopiedMap(prev => ({ ...prev, [key]: false }));
    }, 1800);
  };

  const countries = Array.from(new Set(items.map(it => it.country))).filter(Boolean);

  // Strictly deduplicate items by unique ID
  const seenIds = new Set<number | string>();
  const displayItems: OtpItem[] = [];
  for (const it of items) {
    if (!it || seenIds.has(it.id)) continue;
    if (selectedService !== 'all' && it.service.toLowerCase() !== selectedService.toLowerCase()) {
      continue;
    }
    if (selectedCountry !== 'all' && it.country.toLowerCase() !== selectedCountry.toLowerCase()) {
      continue;
    }
    seenIds.add(it.id);
    displayItems.push(it);
  }

  const getServiceColor = (name: string) => {
    const s = services.find(x => x.name.toLowerCase() === name.toLowerCase());
    return s?.color || '#12b868';
  };

  const formatTimestamp = (ts: number) => {
    return new Date(ts * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  return (
    <div className="space-y-5">
      {/* Search & Status Box */}
      <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-b from-[#131d18] to-[#0d1411] border border-white/[0.09] shadow-[0_16px_36px_rgba(0,0,0,0.5)]">
        <div className="space-y-2.5">
          {/* Input */}
          <div className="relative flex items-center rounded-xl bg-black/50 border border-white/10 focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-500/20 transition-all">
            <Search className="w-4 h-4 text-neutral-400 ml-3.5 flex-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Enter phone number or range..."
              className="w-full bg-transparent border-0 px-3 py-3 text-sm font-mono text-white placeholder-neutral-500 outline-none"
            />
            {searchQuery && (
              <button
                onClick={onClearSearch}
                className="p-2 text-neutral-400 hover:text-white mr-1.5 transition-colors"
                title="Clear"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Clean Non-wrapping Status Line */}
          <div className="flex items-center justify-between text-[11px] sm:text-xs text-neutral-400 px-1 pt-0.5">
            <div className="flex items-center gap-2 truncate">
              <span className="flex h-2 w-2 relative flex-none">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span className="truncate font-medium">
                {searchQuery ? (
                  <>Watching <strong className="text-emerald-400 font-mono">{searchQuery}</strong> in real-time</>
                ) : (
                  <>Real-time stream connected</>
                )}
              </span>
            </div>

            <div className="font-mono flex-none ml-2">
              <strong className="text-white font-bold">{todayCount}</strong> OTPs captured today
            </div>
          </div>
        </div>
      </div>

      {/* Section Header */}
      <div className="flex items-center justify-between px-0.5">
        <h2 className="flex items-center gap-2 font-black text-xs uppercase tracking-widest text-emerald-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Live Codes Feed</span>
        </h2>
        <span className="text-xs text-neutral-400 font-mono">
          <span className="text-white font-bold">{displayItems.length}</span> active
        </span>
      </div>

      {/* Filter Chips & Country Select */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        {/* Service Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
          <button
            onClick={() => {
              setSelectedService('all');
              triggerHaptic('light');
            }}
            className={`px-3.5 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
              selectedService === 'all'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-black shadow-[0_2px_14px_rgba(18,184,104,0.4)]'
                : 'bg-neutral-900/90 border border-white/10 text-neutral-400 hover:text-white'
            }`}
          >
            All
          </button>
          {['WhatsApp', 'Telegram', 'Facebook', 'Instagram', 'Google', 'TikTok', 'Binance', 'bKash'].map(svcName => (
            <button
              key={svcName}
              onClick={() => {
                setSelectedService(svcName);
                triggerHaptic('light');
              }}
              className={`px-3 py-1.5 rounded-full text-xs font-bold transition-all whitespace-nowrap ${
                selectedService.toLowerCase() === svcName.toLowerCase()
                  ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-black shadow-[0_2px_14px_rgba(18,184,104,0.4)]'
                  : 'bg-neutral-900/90 border border-white/10 text-neutral-400 hover:text-white'
              }`}
            >
              {svcName}
            </button>
          ))}
        </div>

        {/* Country Dropdown */}
        {countries.length > 1 && (
          <div className="flex items-center gap-1.5 self-start sm:self-auto flex-none">
            <Globe className="w-3.5 h-3.5 text-neutral-400" />
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="bg-neutral-900/90 border border-white/15 text-xs text-neutral-200 rounded-lg px-2.5 py-1.5 outline-none focus:border-emerald-500 font-medium"
            >
              <option value="all">All Countries ({countries.length})</option>
              {countries.map(c => (
                <option key={c} value={c} className="bg-neutral-950">
                  {c}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {/* Codes List */}
      <div className="space-y-3.5">
        {displayItems.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-[#0e1512] border border-white/10 text-neutral-400">
            <Radio className="w-10 h-10 text-neutral-600 mx-auto mb-3 animate-pulse" />
            <h3 className="text-sm font-bold text-white mb-1">
              {searchQuery ? 'No codes found for this number' : 'Waiting for incoming verification codes...'}
            </h3>
            <p className="text-xs text-neutral-500 max-w-sm mx-auto">
              {searchQuery 
                ? 'Keep this window open. As soon as an SMS or OTP is sent to this number, it will arrive automatically.'
                : 'Incoming real-time verification codes will appear here instantly.'}
            </p>
          </div>
        ) : (
          displayItems.map((item, idx) => {
            const isFresh = freshIds.has(item.id) || idx === 0;
            const accentColor = getServiceColor(item.service);
            const copyCodeKey = `code_${item.id}`;
            const copyNumKey = `num_${item.id}`;
            const copyRangeKey = `rng_${item.id}`;

            return (
              <article
                key={`otp_${item.id}_${idx}`}
                className={`relative overflow-hidden p-4 sm:p-5 rounded-2xl bg-gradient-to-b from-[#131d18] via-[#0f1714] to-[#0a100d] border border-white/[0.08] shadow-[0_12px_28px_rgba(0,0,0,0.35)] transition-all duration-300 hover:border-emerald-500/35 ${
                  isFresh ? 'ring-1 ring-emerald-500/50 shadow-[0_0_30px_rgba(18,184,104,0.18)] flash-new' : ''
                }`}
              >
                {/* Left accent stripe */}
                <div 
                  className="absolute left-0 top-3 bottom-3 w-1 rounded-r-md opacity-90"
                  style={{ backgroundColor: accentColor }}
                />

                {/* Top header row: Service Avatar + Name + Live Badge + Time + Country */}
                <div className="flex items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2.5">
                    <span 
                      className="w-7 h-7 rounded-lg flex items-center justify-center font-black text-xs text-white uppercase shadow-sm flex-none"
                      style={{ backgroundColor: accentColor }}
                    >
                      {item.service[0]}
                    </span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-extrabold text-sm text-white uppercase tracking-wider">
                          {item.service}
                        </span>
                        {isFresh && (
                          <span className="px-1.5 py-0.2 rounded text-[8.5px] font-black tracking-widest uppercase bg-emerald-500 text-black">
                            LATEST
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-neutral-400 font-medium">
                        EX LIVE OTP &bull; {item.flag} {item.country}
                      </span>
                    </div>
                  </div>

                  <div className="text-right flex-none">
                    <div className="font-mono text-xs font-bold text-white tracking-tight">
                      {formatTimestamp(item.ts)}
                    </div>
                    <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">
                      VERIFIED
                    </div>
                  </div>
                </div>

                {/* Number & Range Info Pill */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 my-2.5 text-xs bg-black/40 p-2.5 rounded-xl border border-white/[0.05]">
                  {/* Phone number */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-neutral-400 text-[11px]">Number:</span>
                    <div className="flex items-center gap-1.5 font-mono font-bold text-white">
                      <span>{item.number}</span>
                      <button
                        onClick={() => handleCopy(item.number, copyNumKey)}
                        className="p-1 hover:text-emerald-400 text-neutral-400 transition-colors"
                        title="Copy number"
                      >
                        {copiedMap[copyNumKey] ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>

                  {/* Range */}
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-neutral-400 text-[11px]">Range:</span>
                    <div className="flex items-center gap-1.5 font-mono text-emerald-300">
                      <span>{item.range}</span>
                      <button
                        onClick={() => handleCopy(item.range, copyRangeKey)}
                        className="p-1 hover:text-emerald-400 text-neutral-400 transition-colors"
                        title="Copy range"
                      >
                        {copiedMap[copyRangeKey] ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Big Monospace OTP Code */}
                <div className="my-3 py-3 px-4 rounded-xl bg-black/60 border border-emerald-500/25 text-center relative group">
                  <div className="text-[10px] uppercase tracking-widest text-neutral-400 font-bold mb-0.5">
                    Verification Code
                  </div>
                  <div className="font-mono text-3xl sm:text-4xl font-black tracking-[0.16em] text-white selection:bg-emerald-500/40 drop-shadow-[0_0_24px_rgba(18,184,104,0.35)]">
                    {item.code}
                  </div>
                </div>

                {/* SMS Text snippet */}
                {item.message && (
                  <div className="flex items-start gap-2 p-2.5 rounded-lg bg-neutral-950/70 border border-white/5 text-[11px] text-neutral-300 font-mono my-2.5">
                    <MessageSquare className="w-3.5 h-3.5 text-neutral-500 flex-none mt-0.5" />
                    <p className="line-clamp-2 leading-relaxed">
                      {item.message}
                    </p>
                  </div>
                )}

                {/* Action button: Copy Code */}
                <button
                  onClick={() => handleCopy(item.code, copyCodeKey)}
                  className={`w-full py-2.5 px-4 rounded-xl font-black text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all active:scale-[0.98] ${
                    copiedMap[copyCodeKey]
                      ? 'bg-emerald-500 text-black shadow-[0_0_20px_rgba(18,184,104,0.5)]'
                      : 'bg-white/[0.06] hover:bg-white/[0.1] text-white border border-white/10 hover:border-emerald-500/40'
                  }`}
                >
                  {copiedMap[copyCodeKey] ? (
                    <>
                      <Check className="w-4 h-4 text-black" />
                      <span>Code Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-emerald-400" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </article>
            );
          })
        )}
      </div>
    </div>
  );
};
