import React, { useState } from 'react';
import { 
  Smartphone, 
  Globe, 
  ShieldCheck, 
  Zap, 
  Clock, 
  ArrowRight, 
  AlertCircle,
  CheckCircle2,
  Send
} from 'lucide-react';
import { CountryInfo, ServiceInfo, RentedNumber } from '../types';
import { triggerHaptic } from '../utils/audio';

interface NumberBotProps {
  countries: CountryInfo[];
  services: ServiceInfo[];
  onRentSuccess: (rental: RentedNumber) => void;
  onGoToMyNumbers: () => void;
}

export const NumberBot: React.FC<NumberBotProps> = ({
  countries,
  services,
  onRentSuccess,
  onGoToMyNumbers,
}) => {
  const [selectedCountry, setSelectedCountry] = useState<CountryInfo>(countries[0] || { name: 'France', code: '33', flag: '🇫🇷', prefix: '337' });
  const [selectedService, setSelectedService] = useState<ServiceInfo>(services[0] || { name: 'WhatsApp', letter: 'W', color: '#25d366', defaultMsg: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [lastRented, setLastRented] = useState<RentedNumber | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleRent = async () => {
    setIsLoading(true);
    setError(null);
    triggerHaptic('medium');

    try {
      const res = await fetch('/api/rent', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          country: selectedCountry.name,
          service: selectedService.name,
        }),
      });

      const data = await res.json();
      if (data.ok && data.rental) {
        setLastRented(data.rental);
        onRentSuccess(data.rental);
        triggerHaptic('ok');
      } else {
        throw new Error(data.error || 'Failed to activate number');
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Error connecting to StexSMS rental API';
      setError(msg);
      triggerHaptic('err');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#0e1713] via-[#0f2017] to-[#0a1410] border border-emerald-500/20 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-black uppercase tracking-widest">
                STEXSMS VIRTUAL POOL
              </span>
              <span className="text-xs text-neutral-400">&bull; Instant Activation</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              Rent Virtual Number For OTP
            </h2>
            <p className="text-xs sm:text-sm text-neutral-400 max-w-xl">
              Get an instant dedicated disposable virtual number for WhatsApp, Telegram, Facebook, Google, and 20+ services. Codes will appear on this dashboard in real-time.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onGoToMyNumbers}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-neutral-900 border border-white/10 hover:border-emerald-500/40 text-xs font-bold text-neutral-200 transition-all"
            >
              <Clock className="w-4 h-4 text-emerald-400" />
              <span>View Active Numbers</span>
            </button>
          </div>
        </div>
      </div>

      {/* Success Notification Box */}
      {lastRented && (
        <div className="p-5 rounded-2xl bg-emerald-950/40 border border-emerald-500/40 text-white space-y-3 animate-fade-in shadow-[0_0_30px_rgba(18,184,104,0.15)]">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-none" />
              <h3 className="text-sm font-bold uppercase tracking-wider text-emerald-300">
                Number Activated Successfully!
              </h3>
            </div>
            <span className="text-xs font-mono text-neutral-400">15 min countdown</span>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between p-3.5 rounded-xl bg-black/60 border border-white/10 gap-3">
            <div>
              <div className="text-[11px] text-neutral-400 uppercase font-bold tracking-wider">
                Assigned Phone Number ({lastRented.service})
              </div>
              <div className="text-2xl font-mono font-black text-white selection:bg-emerald-500/30">
                {lastRented.number}
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(lastRented.number);
                  triggerHaptic('ok');
                }}
                className="px-3.5 py-2 rounded-lg bg-emerald-500 text-black text-xs font-bold uppercase tracking-wider hover:bg-emerald-400 transition-colors"
              >
                Copy Number
              </button>
              <button
                onClick={onGoToMyNumbers}
                className="px-3.5 py-2 rounded-lg bg-neutral-800 border border-white/10 text-white text-xs font-bold uppercase tracking-wider hover:bg-neutral-700 transition-colors"
              >
                Go to Waiting Radar
              </button>
            </div>
          </div>
          <p className="text-xs text-neutral-400">
            Paste this number into {lastRented.service}. Once they send the SMS, your verification code will automatically arrive here!
          </p>
        </div>
      )}

      {error && (
        <div className="p-4 rounded-xl bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-red-400 flex-none" />
          <span>{error}</span>
        </div>
      )}

      {/* Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Step 1: Select Country */}
        <div className="p-5 rounded-2xl bg-[#0e1512] border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-black flex items-center justify-center border border-emerald-500/30">
                1
              </span>
              <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                Choose Country
              </h3>
            </div>
            <span className="text-xs text-neutral-400">
              Selected: <strong className="text-white">{selectedCountry.name}</strong>
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1">
            {countries.map(c => {
              const isSelected = selectedCountry.name === c.name;
              return (
                <button
                  key={c.name}
                  onClick={() => {
                    setSelectedCountry(c);
                    triggerHaptic('light');
                  }}
                  className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                    isSelected
                      ? 'bg-emerald-500/15 border-emerald-500 text-white shadow-[0_0_15px_rgba(18,184,104,0.2)]'
                      : 'bg-neutral-900/60 border-white/5 text-neutral-300 hover:border-white/20'
                  }`}
                >
                  <span className="text-xl">{c.flag}</span>
                  <div className="truncate">
                    <div className="text-xs font-bold truncate">{c.name}</div>
                    <div className="text-[10px] text-neutral-500 font-mono">+{c.code}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step 2: Select Service */}
        <div className="p-5 rounded-2xl bg-[#0e1512] border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-black flex items-center justify-center border border-emerald-500/30">
                2
              </span>
              <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                Choose Service
              </h3>
            </div>
            <span className="text-xs text-neutral-400">
              Selected: <strong className="text-white">{selectedService.name}</strong>
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 max-h-72 overflow-y-auto pr-1">
            {services.map(s => {
              const isSelected = selectedService.name === s.name;
              return (
                <button
                  key={s.name}
                  onClick={() => {
                    setSelectedService(s);
                    triggerHaptic('light');
                  }}
                  className={`p-3 rounded-xl border text-left flex items-center gap-2.5 transition-all ${
                    isSelected
                      ? 'bg-emerald-500/15 border-emerald-500 text-white shadow-[0_0_15px_rgba(18,184,104,0.2)]'
                      : 'bg-neutral-900/60 border-white/5 text-neutral-300 hover:border-white/20'
                  }`}
                >
                  <span
                    className="w-6 h-6 rounded-md flex items-center justify-center text-xs font-black text-white flex-none"
                    style={{ backgroundColor: s.color }}
                  >
                    {s.letter}
                  </span>
                  <div className="truncate">
                    <div className="text-xs font-bold truncate">{s.name}</div>
                    <div className="text-[10px] text-emerald-400 font-mono">Instant OTP</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Activation Action Button */}
      <div className="p-5 rounded-2xl bg-[#0e1512] border border-emerald-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-xs text-neutral-400 space-y-0.5">
          <div className="text-white font-bold text-sm">
            Ready to activate: <span className="text-emerald-400">{selectedCountry.flag} {selectedCountry.name}</span> for <span className="text-emerald-400">{selectedService.name}</span>
          </div>
          <div>StexSMS API Key: <strong className="font-mono text-neutral-300">MK50IRMEXS8</strong></div>
        </div>

        <button
          onClick={handleRent}
          disabled={isLoading}
          className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-black font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-all shadow-[0_8px_24px_rgba(18,184,104,0.35)] active:scale-95 disabled:opacity-50"
        >
          <Zap className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          <span>{isLoading ? 'Activating Number...' : 'Get Virtual Number'}</span>
        </button>
      </div>
    </div>
  );
};
