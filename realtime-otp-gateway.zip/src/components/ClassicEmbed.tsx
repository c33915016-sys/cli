import React from 'react';
import { ExternalLink, Smartphone, RotateCcw } from 'lucide-react';

export const ClassicEmbed: React.FC = () => {
  return (
    <div className="space-y-4">
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0e1512] border border-white/10 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-emerald-400" />
            <span>Classic Telegram Mini App View</span>
          </h2>
          <p className="text-xs text-neutral-400">
            Interactive preview of your original HTML Mini App connected to the real-time StexSMS console stream.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="/classic-bot"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold uppercase tracking-wider transition-colors"
          >
            <span>Open Standalone</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Frame container designed like a sleek mobile viewport */}
      <div className="flex justify-center py-4">
        <div className="w-full max-w-[480px] h-[780px] rounded-[32px] overflow-hidden border-4 border-neutral-800 shadow-[0_20px_50px_rgba(0,0,0,0.8)] bg-[#07090a]">
          <iframe
            src="/classic-bot"
            title="Classic Telegram Mini App"
            className="w-full h-full border-0"
          />
        </div>
      </div>
    </div>
  );
};
