import React, { useState, useEffect } from 'react';
import { 
  Clock, 
  Smartphone, 
  Check, 
  Copy, 
  XCircle, 
  Radio, 
  AlertCircle, 
  MessageSquare,
  Plus
} from 'lucide-react';
import { RentedNumber, OtpItem } from '../types';
import { triggerHaptic } from '../utils/audio';

interface MyNumbersProps {
  rentals: RentedNumber[];
  items: OtpItem[];
  onRentNew: () => void;
  onCancelNumber: (number: string) => void;
}

export const MyNumbers: React.FC<MyNumbersProps> = ({
  rentals,
  items,
  onRentNew,
  onCancelNumber,
}) => {
  const [copiedMap, setCopiedMap] = useState<Record<string, boolean>>({});
  const [, setTick] = useState(0);

  // Re-render countdown every second
  useEffect(() => {
    const timer = setInterval(() => {
      setTick(t => t + 1);
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    triggerHaptic('ok');
    setCopiedMap(prev => ({ ...prev, [key]: true }));
    setTimeout(() => {
      setCopiedMap(prev => ({ ...prev, [key]: false }));
    }, 1800);
  };

  const formatRemainingTime = (expiresAt: number) => {
    const diff = Math.max(0, Math.floor((expiresAt - Date.now()) / 1000));
    const mins = Math.floor(diff / 60);
    const secs = diff % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="space-y-6">
      {/* Header bar */}
      <div className="p-4 sm:p-5 rounded-2xl bg-[#0e1512] border border-white/10 flex flex-wrap items-center justify-between gap-3 shadow-md">
        <div>
          <h2 className="text-base font-bold uppercase tracking-wider text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-emerald-400" />
            <span>My Active Numbers &amp; OTP Radar</span>
          </h2>
          <p className="text-xs text-neutral-400">
            Real-time listener for your rented numbers. When SMS arrives, it will be caught immediately.
          </p>
        </div>

        <button
          onClick={onRentNew}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-extrabold uppercase tracking-wider transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>Rent Another Number</span>
        </button>
      </div>

      {rentals.length === 0 ? (
        <div className="p-12 text-center rounded-2xl bg-[#0e1512] border border-white/10 text-neutral-400 space-y-3">
          <Smartphone className="w-12 h-12 text-neutral-600 mx-auto animate-pulse" />
          <h3 className="text-base font-bold text-white">No Active Numbers Yet</h3>
          <p className="text-xs text-neutral-500 max-w-sm mx-auto">
            You don&#39;t have any active virtual numbers. Go to &quot;Rent / Get Number&quot; to pick a country and service, and your OTP codes will appear here instantly.
          </p>
          <button
            onClick={onRentNew}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-500 text-black font-extrabold text-xs uppercase tracking-wider shadow-lg hover:bg-emerald-400 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Get Your First Number</span>
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {rentals.map((rental, index) => {
            const isWaiting = rental.status === 'waiting';
            const isReceived = rental.status === 'received' || !!rental.receivedCode;
            const remaining = formatRemainingTime(rental.expiresAt);
            const copyNumKey = `num_${rental.id}`;
            const copyCodeKey = `code_${rental.id}`;

            return (
              <div
                key={`rental_${rental.id}_${index}`}
                className={`p-5 rounded-2xl border transition-all duration-300 ${
                  isReceived
                    ? 'bg-gradient-to-b from-[#101d16] to-[#0e1512] border-emerald-500/50 shadow-[0_0_30px_rgba(18,184,104,0.15)]'
                    : isWaiting
                    ? 'bg-[#0e1512] border-amber-500/40 shadow-lg'
                    : 'bg-[#0a0f0d] border-white/10 opacity-60'
                }`}
              >
                {/* Header row */}
                <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
                  <div className="flex items-center gap-2.5">
                    <span className="text-2xl">{rental.flag}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white uppercase tracking-wider">
                          {rental.service} ({rental.country})
                        </span>
                        {isWaiting && (
                          <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest bg-amber-500/20 text-amber-400 border border-amber-500/30 animate-pulse">
                            WAITING FOR SMS
                          </span>
                        )}
                        {isReceived && (
                          <span className="px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest bg-emerald-500 text-black">
                            CODE RECEIVED
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-neutral-400">
                        Rented via StexSMS Gateway
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    {isWaiting && (
                      <div className="px-3 py-1 rounded-lg bg-black/50 border border-white/10 font-mono text-xs text-amber-400 font-bold flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5" />
                        <span>Expires in {remaining}</span>
                      </div>
                    )}
                    {isWaiting && (
                      <button
                        onClick={() => onCancelNumber(rental.number)}
                        className="p-1.5 rounded-lg text-neutral-500 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                        title="Cancel this number"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* Number Card */}
                <div className="p-3.5 rounded-xl bg-black/40 border border-white/10 flex items-center justify-between gap-3 mb-3">
                  <div>
                    <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider">
                      Phone Number
                    </span>
                    <div className="font-mono text-xl sm:text-2xl font-black text-white selection:bg-emerald-500/30">
                      {rental.number}
                    </div>
                  </div>
                  <button
                    onClick={() => handleCopy(rental.number, copyNumKey)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-800 hover:bg-neutral-700 text-xs font-bold text-white transition-colors"
                  >
                    {copiedMap[copyNumKey] ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-neutral-400" />
                        <span>Copy</span>
                      </>
                    )}
                  </button>
                </div>

                {/* Radar Bar when waiting */}
                {isWaiting && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-xs text-amber-400/90 font-mono">
                      <span className="flex items-center gap-1.5">
                        <Radio className="w-3.5 h-3.5 animate-spin" />
                        Listening for incoming {rental.service} OTP...
                      </span>
                      <span>Polling StexSMS API</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-neutral-900 overflow-hidden relative">
                      <div className="h-full bg-gradient-to-r from-amber-500 via-emerald-400 to-amber-500 w-1/3 rounded-full animate-[scanline_2s_ease-in-out_infinite]" />
                    </div>
                  </div>
                )}

                {/* Received Code Display */}
                {isReceived && rental.receivedCode && (
                  <div className="mt-3 p-4 rounded-xl bg-black/60 border border-emerald-500/40 text-center space-y-2">
                    <div className="text-[11px] uppercase font-bold text-neutral-400 tracking-wider">
                      Your Verification Code
                    </div>
                    <div className="font-mono text-3xl sm:text-4xl font-black text-emerald-400 tracking-widest">
                      {rental.receivedCode}
                    </div>

                    {rental.receivedMessage && (
                      <div className="text-xs text-neutral-300 font-mono bg-neutral-900/60 p-2.5 rounded-lg border border-white/5 text-left flex items-start gap-2">
                        <MessageSquare className="w-3.5 h-3.5 text-neutral-500 flex-none mt-0.5" />
                        <p>{rental.receivedMessage}</p>
                      </div>
                    )}

                    <button
                      onClick={() => handleCopy(rental.receivedCode!, copyCodeKey)}
                      className="w-full py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-black font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-2 transition-colors shadow-md"
                    >
                      {copiedMap[copyCodeKey] ? (
                        <>
                          <Check className="w-4 h-4 text-black" />
                          <span>Code Copied!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 text-black" />
                          <span>Copy Code</span>
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
