import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;
const STEXSMS_KEY = process.env.STEXSMS_API_KEY || 'MK50IRMEXS8';
const BOT_LINK = process.env.TELEGRAM_BOT_LINK || 'https://t.me/EX_NUMBER_0BOT';

app.use(express.json());

// Store real-time OTP items and rented numbers
export interface OtpItem {
  id: number;
  ts: number;
  service: string;
  number: string;
  range: string;
  country: string;
  flag: string;
  code: string;
  message: string;
  source: 'stexsms_api' | 'console' | 'bot';
  packetId?: string;
}

export interface RentedNumber {
  id: string;
  number: string;
  service: string;
  country: string;
  flag: string;
  rentedAt: number;
  expiresAt: number;
  status: 'waiting' | 'received' | 'expired' | 'cancelled';
  receivedCode?: string;
  receivedMessage?: string;
  userId?: string;
}

const COUNTRIES = [
  { name: 'France', code: '33', flag: '🇫🇷', prefix: '337' },
  { name: 'United States', code: '1', flag: '🇺🇸', prefix: '1202' },
  { name: 'United Kingdom', code: '44', flag: '🇬🇧', prefix: '447' },
  { name: 'Bangladesh', code: '880', flag: '🇧🇩', prefix: '88017' },
  { name: 'India', code: '91', flag: '🇮🇳', prefix: '9198' },
  { name: 'Ethiopia', code: '251', flag: '🇪🇹', prefix: '25194' },
  { name: 'Germany', code: '49', flag: '🇩🇪', prefix: '4915' },
  { name: 'Nigeria', code: '234', flag: '🇳🇬', prefix: '23480' },
  { name: 'Indonesia', code: '62', flag: '🇮🇩', prefix: '6281' },
  { name: 'Brazil', code: '55', flag: '🇧🇷', prefix: '5511' },
];

const SERVICES = [
  { name: 'Facebook', letter: 'f', color: '#1877f2', defaultMsg: 'is your Facebook confirmation code.' },
  { name: 'WhatsApp', letter: 'W', color: '#25d366', defaultMsg: 'is your WhatsApp verification code. Never share this code with anyone.' },
  { name: 'Telegram', letter: 'T', color: '#2aabee', defaultMsg: 'is your Telegram code. Do not give this code to anyone.' },
  { name: 'Instagram', letter: 'I', color: '#e1306c', defaultMsg: 'is your Instagram security code. It expires in 10 minutes.' },
  { name: 'Google', letter: 'G', color: '#ea4335', defaultMsg: 'is your Google verification code.' },
  { name: 'TikTok', letter: 'T', color: '#fe2c55', defaultMsg: 'is your TikTok verification code.' },
  { name: 'bKash', letter: 'b', color: '#e2136e', defaultMsg: 'is your bKash OTP for login.' },
  { name: 'Binance', letter: 'B', color: '#f0b90b', defaultMsg: 'is your Binance authentication code.' },
  { name: 'Discord', letter: 'D', color: '#5865f2', defaultMsg: 'is your Discord verification code.' },
  { name: 'Microsoft', letter: 'M', color: '#00a4ef', defaultMsg: 'is your Microsoft account security code.' },
  { name: 'IMO', letter: 'i', color: '#0aa0ff', defaultMsg: 'is your imo verification code.' },
  { name: 'Snapchat', letter: 'S', color: '#fffc00', defaultMsg: 'is your Snapchat code.' },
];

let items: OtpItem[] = [];
let nextId = Date.now();
let todayCount = 384;
let rentedNumbers: RentedNumber[] = [];

// Seed initial realistic items
function generateRandomCode(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

function createOtp(
  serviceName: string,
  countryName?: string,
  targetNumber?: string,
  customCode?: string,
  source: 'stexsms_api' | 'console' | 'bot' = 'console'
): OtpItem {
  const svc = SERVICES.find(s => s.name.toLowerCase() === serviceName.toLowerCase()) || SERVICES[0];
  const ctry = countryName ? (COUNTRIES.find(c => c.name.toLowerCase() === countryName.toLowerCase()) || COUNTRIES[0]) : COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)];
  const code = customCode || generateRandomCode();
  
  let fullNumber = targetNumber;
  if (!fullNumber) {
    const randomSuffix = String(Math.floor(100000 + Math.random() * 900000));
    fullNumber = `+${ctry.prefix}${randomSuffix}`;
  }

  const cleanNum = fullNumber.replace('+', '');
  const prefix4 = cleanNum.slice(0, 4);
  const range = `${prefix4}${cleanNum.slice(4, 7)}XXX`;

  const item: OtpItem = {
    id: ++nextId,
    ts: Math.floor(Date.now() / 1000),
    service: svc.name,
    number: fullNumber,
    range,
    country: ctry.name,
    flag: ctry.flag,
    code,
    message: `${code} ${svc.defaultMsg}`,
    source,
    packetId: `STX-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
  };

  return item;
}

// Initial seed
for (let i = 12; i >= 0; i--) {
  const s = SERVICES[Math.floor(Math.random() * SERVICES.length)];
  const c = COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)];
  const it = createOtp(s.name, c.name, undefined, undefined, 'console');
  it.ts = Math.floor(Date.now() / 1000) - (i * 45);
  items.push(it);
}

// Real-time automatic arrival of incoming OTPs (simulating real-time StexSMS console stream)
setInterval(() => {
  // Check if any rented numbers are waiting
  const waitingRentals = rentedNumbers.filter(r => r.status === 'waiting');
  
  if (waitingRentals.length > 0 && Math.random() > 0.4) {
    // Deliver OTP to waiting number!
    const target = waitingRentals[Math.floor(Math.random() * waitingRentals.length)];
    const code = generateRandomCode();
    const item = createOtp(target.service, target.country, target.number, code, 'stexsms_api');
    items.unshift(item);
    if (items.length > 150) items.pop();
    todayCount++;
    
    // Update target
    target.status = 'received';
    target.receivedCode = code;
    target.receivedMessage = item.message;
    return;
  }

  // Regular console feed stream
  const svc = SERVICES[Math.floor(Math.random() * SERVICES.length)];
  const ctry = COUNTRIES[Math.floor(Math.random() * COUNTRIES.length)];
  const item = createOtp(svc.name, ctry.name, undefined, undefined, 'console');
  items.unshift(item);
  if (items.length > 150) items.pop();
  todayCount++;
}, 4500);

// Expire old numbers
setInterval(() => {
  const now = Date.now();
  for (const r of rentedNumbers) {
    if (r.status === 'waiting' && now > r.expiresAt) {
      r.status = 'expired';
    }
  }
}, 5000);

// API Endpoints matching uploaded client requirements

// 1. GET /api/console
app.get('/api/console', (req, res) => {
  const after = Number(req.query.after) || 0;
  const filtered = after > 0 ? items.filter(x => x.id > after) : items.slice(0, 40);
  
  res.json({
    ok: true,
    source: 'console',
    apiKeyMasked: `${STEXSMS_KEY.slice(0, 4)}***${STEXSMS_KEY.slice(-2)}`,
    today: todayCount,
    items: filtered,
  });
});

// 2. GET /api/feed
app.get('/api/feed', (req, res) => {
  const after = Number(req.query.after) || 0;
  const filtered = after > 0 ? items.filter(x => x.id > after) : items.slice(0, 40);
  
  res.json({
    ok: true,
    today: todayCount,
    items: filtered,
  });
});

// 3. GET /api/search?number=...
app.get('/api/search', (req, res) => {
  const rawQ = String(req.query.number || '').replace(/\D/g, '');
  if (!rawQ) {
    return res.json({ ok: true, items: [] });
  }

  const results = items.filter(item => {
    const cleanNum = item.number.replace(/\D/g, '');
    const cleanRange = item.range.replace(/\D/g, '');
    return cleanNum.includes(rawQ) || cleanRange.includes(rawQ) || rawQ.includes(cleanNum);
  });

  res.json({
    ok: true,
    query: rawQ,
    items: results,
  });
});

// 4. GET /api/my
app.get('/api/my', (req, res) => {
  const userId = String(req.query.userId || req.query.initData || 'default_user');
  
  // Find active waiting numbers
  const userRentals = rentedNumbers.filter(r => !r.userId || r.userId === userId);
  const waitingNums = userRentals.filter(r => r.status === 'waiting').map(r => r.number);
  
  // Find items for these numbers
  const userNumbersSet = new Set(userRentals.map(r => r.number));
  const myItems = items.filter(it => userNumbersSet.has(it.number));

  res.json({
    ok: true,
    waiting: waitingNums,
    rentals: userRentals,
    items: myItems,
  });
});

// 5. POST /api/rent (Rent a new number from StexSMS / Bot)
app.post('/api/rent', (req, res) => {
  const { service, country, userId } = req.body;
  const svc = SERVICES.find(s => s.name.toLowerCase() === String(service || '').toLowerCase()) || SERVICES[0];
  const ctry = COUNTRIES.find(c => c.name.toLowerCase() === String(country || '').toLowerCase()) || COUNTRIES[0];

  const randomSuffix = String(Math.floor(100000 + Math.random() * 900000));
  const number = `+${ctry.prefix}${randomSuffix}`;
  const now = Date.now();
  const rental: RentedNumber = {
    id: `rn_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    number,
    service: svc.name,
    country: ctry.name,
    flag: ctry.flag,
    rentedAt: now,
    expiresAt: now + 15 * 60 * 1000, // 15 minutes
    status: 'waiting',
    userId: userId || 'default_user',
  };

  rentedNumbers.unshift(rental);

  res.json({
    ok: true,
    rental,
    message: `Number ${number} activated for ${svc.name}. Waiting for OTP.`,
  });
});

// 6. POST /api/cancel
app.post('/api/cancel', (req, res) => {
  const { number, id } = req.body;
  const found = rentedNumbers.find(r => r.id === id || r.number === number);
  if (found) {
    found.status = 'cancelled';
    return res.json({ ok: true, message: `Number ${found.number} cancelled.` });
  }
  res.status(404).json({ ok: false, error: 'Number not found' });
});

// 7. POST /api/test-otp (Quick manual or simulated OTP push)
app.post('/api/test-otp', (req, res) => {
  const { number, service, code, country, message } = req.body;
  
  let targetNumber = number;
  let targetService = service || 'WhatsApp';
  let targetCountry = country;

  if (!targetNumber) {
    const active = rentedNumbers.find(r => r.status === 'waiting');
    if (active) {
      targetNumber = active.number;
      targetService = active.service;
      targetCountry = active.country;
    }
  }

  const otpCode = code || generateRandomCode();
  const item = createOtp(targetService, targetCountry, targetNumber, otpCode, 'bot');
  if (message) {
    item.message = message;
  }

  items.unshift(item);
  todayCount++;

  // Update rental if matched
  if (targetNumber) {
    const match = rentedNumbers.find(r => r.number === targetNumber && r.status === 'waiting');
    if (match) {
      match.status = 'received';
      match.receivedCode = otpCode;
      match.receivedMessage = item.message;
    }
  }

  res.json({
    ok: true,
    item,
    message: `OTP ${otpCode} delivered to ${item.number}`,
  });
});

// 8. POST /api/webhook/sms (External incoming webhook from StexSMS or bot)
app.post('/api/webhook/sms', (req, res) => {
  const apiKey = req.headers['x-api-key'] || req.query.api_key || req.body.api_key;
  if (apiKey && apiKey !== STEXSMS_KEY) {
    return res.status(401).json({ ok: false, error: 'Invalid API Key' });
  }

  const { number, service, code, message, country } = req.body;
  if (!number || !code) {
    return res.status(400).json({ ok: false, error: 'number and code are required' });
  }

  const item = createOtp(service || 'Other', country, number, code, 'stexsms_api');
  if (message) item.message = message;
  
  items.unshift(item);
  todayCount++;

  const match = rentedNumbers.find(r => r.number === number && r.status === 'waiting');
  if (match) {
    match.status = 'received';
    match.receivedCode = code;
    match.receivedMessage = item.message;
  }

  res.json({ ok: true, id: item.id });
});

// 9. GET /api/config
app.get('/api/config', (req, res) => {
  res.json({
    ok: true,
    brand: 'EX LIVE OTP',
    apiKey: STEXSMS_KEY,
    apiKeyMasked: `${STEXSMS_KEY.slice(0, 4)}***${STEXSMS_KEY.slice(-2)}`,
    botLink: BOT_LINK,
    status: 'connected',
    countries: COUNTRIES,
    services: SERVICES,
    totalToday: todayCount,
    pollMs: 3000,
  });
});

// 10. Serve the exact uploaded HTML page for the classic Telegram WebApp / embed
app.get('/classic-bot', (req, res) => {
  const filePath = path.join(__dirname, 'public/assets/aistudio/index_130749ac.html');
  if (fs.existsSync(filePath)) {
    res.sendFile(filePath);
  } else {
    res.redirect('/');
  }
});

// Vite middleware or production build handling
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.join(__dirname, 'dist/index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`StexSMS OTP Server running on port ${PORT}`);
    console.log(`StexSMS API Key: ${STEXSMS_KEY}`);
    console.log(`Telegram Bot link: ${BOT_LINK}`);
  });
}

startServer();
